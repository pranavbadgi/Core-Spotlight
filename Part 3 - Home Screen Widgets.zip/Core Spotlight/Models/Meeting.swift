//
//  Meeting.swift
//  Core Spotlight
//
//  Created by Pranav Badgi on 6/28/22.
//

import Foundation

struct Meeting: Codable {
    let meetingName : String
    let hostedBy    : String
    let dateAndTime : String
}
