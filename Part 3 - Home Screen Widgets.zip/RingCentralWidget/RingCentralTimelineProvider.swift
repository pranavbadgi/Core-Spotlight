//
//  RingCentralTimelineProvider.swift
//  RingCentralWidgetExtension
//
//  Created by Pranav Badgi on 7/7/22.
//

import WidgetKit

struct RingCentralTimelineProvider: TimelineProvider {
    
    //MARK: - Properties
    typealias Entry = RingCentralWidgetEntry
    
    let placeholder = Meeting(meetingName: "Weekly", hostedBy: "Manager", dateAndTime: "7/7/2022")
    
    
    
    //MARK: - Helpers
    func placeholder(in context: Context) -> RingCentralWidgetEntry {
        RingCentralWidgetEntry(meeting: placeholder)
    }
    
    func getSnapshot(in context: Context, completion: @escaping (RingCentralWidgetEntry) -> Void) {
        completion(RingCentralWidgetEntry(meeting: placeholder))
    }
    
    func getTimeline(in context: Context, completion: @escaping (Timeline<RingCentralWidgetEntry>) -> Void) {
        let userDefaults = UserDefaults(suiteName: "group.widgetCache")
        if let meeting = userDefaults?.data(forKey: "meeting") {
            do {
                let decoder = JSONDecoder()
                let fetchedMeeting = try decoder.decode(Meeting.self, from: meeting)
                let entry = RingCentralWidgetEntry(meeting: fetchedMeeting)
                let timeline = Timeline(entries: [entry], policy: .never)
                completion(timeline)
            } catch {
                print("DEBUG: Unable to decode")
            }
        }
        
    }
}
