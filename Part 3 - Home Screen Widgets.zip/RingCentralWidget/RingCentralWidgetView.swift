//
//  RingCentralWidgetView.swift
//  RingCentralWidgetExtension
//
//  Created by Pranav Badgi on 7/7/22.
//

import SwiftUI

struct RingCentralWidgetView: View {
    
    var entry: RingCentralWidgetEntry
    
    var body: some View {
        ZStack {
            Text(entry.meeting.meetingName)
                .bold()
                .foregroundColor(.black)
                .font(.title2)
        }.padding(10)
    }
}


