//
//  RingCentralWidgetEntry.swift
//  RingCentralWidgetExtension
//
//  Created by Pranav Badgi on 7/7/22.
//

import WidgetKit

struct RingCentralWidgetEntry: TimelineEntry {
    //MARK: - Properties
    let date = Date()
    let meeting: Meeting
}
