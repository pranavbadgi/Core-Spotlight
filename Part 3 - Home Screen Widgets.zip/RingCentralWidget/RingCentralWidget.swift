//
//  RingCentralWidget.swift
//  RingCentralWidget
//
//  Created by Pranav Badgi on 7/7/22.
//

import WidgetKit
import SwiftUI

@main
struct RingCentralWidget: Widget {
    //MARK: - Properties
    let kind = "RingCentralWidget"
    
    
    //MARK: - Body
    var body: some WidgetConfiguration {
        StaticConfiguration(kind: kind, provider: RingCentralTimelineProvider(), content: { entry in
            RingCentralWidgetView(entry: entry)
        })
        .supportedFamilies([.systemSmall])
        .configurationDisplayName("RingCentral")
        .description("Your upcoming meetings...")
    }
    
}

