//
//  MeetingItem+CoreDataClass.swift
//  Core Spotlight
//
//  Created by Pranav Badgi on 6/28/22.
//
//

import Foundation
import CoreData

@objc(MeetingItem)
public class MeetingItem: NSManagedObject {

}
